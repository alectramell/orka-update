#!/bin/bash

ORKAURL=$(zenity --entry --title="Orka" --text="File URL")

gnome-terminal --title="Orka | Main Pipe.." -x sh -c "cd ~/Desktop && wget -c $ORKAURL" &

(
cd ~/Desktop && wget -c $ORKAURL &
cd ~/Desktop && wget -c $ORKAURL &
cd ~/Desktop && wget -c $ORKAURL &
cd ~/Desktop && wget -c $ORKAURL &
cd ~/Desktop && wget -c $ORKAURL &
) | zenity --progress --pulsate --title="Orka" --text="Downloading (via 5 Pipes).." --percentage=0

clear
