#!/usr/bin/python

import os
import getpass

user = getpass.getuser()
user = str(user)

drop = str('exec /usr/share/orka/drop.sh')

os.system('clear')

os.system(drop)
